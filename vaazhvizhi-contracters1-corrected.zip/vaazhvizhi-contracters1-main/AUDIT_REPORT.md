# Vaazhvizhi Contracters — static audit

## Findings
- `index.html` and the supplied `script.js` were from incompatible versions.
- The supplied script looked for IDs such as `projectForm`, `detailName`, `whatsappSubmit`, and `primary-nav`; the HTML instead uses `detailedQuoteForm`, `quoteName`, a direct WhatsApp anchor, and `primaryNav`.
- Because the script returned early when `#projectForm` was missing, the detailed quote form's open/step/submit behavior was not wired to the actual HTML.
- The supplied HTML already keeps the detailed form hidden initially and the Immediate Enquiry action is a direct WhatsApp link.
- `Code.gs` expects `name`, `phone`, `location`, `projectType`, `service`, and `requirement`; the corrected script posts those exact fields. Building area and expected start are included in `requirement` so they are not discarded.

## Changes in the corrected ZIP
- Replaced `script.js` with a version matched to the current `index.html`.
- Wired the Get Detailed Quote button and hero CTA to reveal the hidden detailed form.
- Wired project-type cards to open the detailed form and preselect the project type.
- Added two-step validation and progress updates using the HTML's actual IDs.
- Kept Immediate Enquiry as a direct WhatsApp link; it does not post to Google Sheets.
- Detailed Quote submits to the configured Apps Script endpoint through the hidden iframe; it does not open WhatsApp.
- Added success/error status handling and a timeout when the endpoint response cannot be confirmed.

## Static checks performed
- JavaScript syntax check: passed with `node --check`.
- Every `#id` selector used by the corrected script exists in `index.html`.
- No duplicate HTML IDs found.
- Confirmed the detailed form is initially hidden.
- Confirmed the Immediate Enquiry link points directly to `https://wa.me/919025541161`.
- Confirmed the frontend payload names match the `Code.gs` receiver contract.

## Not yet verified
This is a static code audit, not a live deployment test. I have not submitted a real quote to your Google Sheet or confirmed email delivery. Before using it live, confirm the Apps Script deployment is active, permits access from website visitors, is bound to the correct spreadsheet (or has `SPREADSHEET_ID` set), and has authorization for email notifications.
